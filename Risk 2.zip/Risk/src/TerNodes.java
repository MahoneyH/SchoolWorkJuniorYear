
import javax.swing.JToggleButton;

public class TerNodes {
    
    private String name; //unique id
    Player owner; //
    int armies;
    int fortified;
    int i;
    int j;
    JToggleButton button;

    public TerNodes(String name, Player owner, int armies, int fortified, JToggleButton button, int i, int j) {
        this.name = name;
        this.owner = owner;
        this.armies = armies;
        this.fortified = fortified;
        this.button = button;
        this.i = i;
        this.j = j;
        button.setText(name + "\n (" + armies + ") " + " + " + fortified);           
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        button.setText(name + "\n (" + armies + ") " + " + " + fortified);
    }

    public Player getOwner() {
        return owner;
    }

    public void setOwner(Player owner) {
        this.owner = owner;
        button.setBackground(owner.getTeamColor());
    }

    public int getArmies() {
        return armies;
    }

    public void setArmies(int armies) {
        this.armies = armies;
        button.setText(name + "\n (" + armies + ") " + " + " + fortified); 
    }

    public int getFortified() {
        return fortified;
    }

    public void setFortified(int fortified) {
        this.fortified += fortified;
        button.setText(name + "\n (" + armies + ") " + " + " + fortified);
    }
    
    public int getI() {
        return i;
    }
    
    public int getJ() {
        return j;
    }

    @Override
    public String toString() {
        return name + " (" + armies + ")" + " + " + fortified;
        
    
    }
    
    
            
    
}
