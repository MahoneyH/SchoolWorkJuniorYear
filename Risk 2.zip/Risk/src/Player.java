/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;

/**
 *
 * @author oy5836jw
 */
public class Player {
    
    private String teamName;
    private Color teamColor;
    private int territoryControlled;
    private int totalArmies;
    int avalibleArmies;
    int numFort;

    public Player(String teamName, Color teamColor, int territoryControlled, int totalArmies, int avalibleArmies, int numFort) {
        this.teamName = teamName;
        this.teamColor = teamColor;
        this.territoryControlled = territoryControlled;
        this.totalArmies = totalArmies;
        this.avalibleArmies = avalibleArmies;
        this.numFort = numFort;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public Color getTeamColor() {
        return teamColor;
    }

    public void setTeamColor(Color teamColor) {
        this.teamColor = teamColor;
    }

    public int getTerritoryControlled() {
        return territoryControlled;
    }

    public void setTerritoryControlled(int territoryControlled) {
        this.territoryControlled = territoryControlled;
    }

    public int getTotalArmies() {
        return totalArmies;
    }

    public void setTotalArmies(int totalArmies) {
        this.totalArmies = totalArmies;
    }

    public int getAvalibleArmies() {
        return avalibleArmies;
    }

    public void setAvalibleArmies(int avalibleArmies) {
        this.avalibleArmies = avalibleArmies;
    }
    
    public int getNumFort(){
        return numFort;
    }
    
    public void setNumFort(int numFort){
        this.numFort = numFort;
    }
    

    @Override
    public String toString() {
        return "Player:  " + teamName + "\n"
                + "Color: " + teamColor + "\n"
                + "Territories Owned: " + territoryControlled + "\n" 
                + "Armies Owned: " + totalArmies + "\n"
                + "Armies to place: " + avalibleArmies + "\n"
                + "Number of Fortified " + numFort;
    
    }   
}