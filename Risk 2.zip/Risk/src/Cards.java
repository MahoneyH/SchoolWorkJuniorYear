
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author vv9924lk
 */

public class Cards {
    
    private String desc;
    private int effect;
    
    
    public Cards (String desc, int effect) {
        this.desc = desc;
        this.effect = effect;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getEffect() {
        return effect;
    }

    public void setEffect(int effect) {
        this.effect = effect;
    }
    
   
    
    public String toString() {
        return this.getDesc() + " " + this.getEffect() + ".";
    }
} //end class