import java.awt.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author Team
 * 
 */

public class RiskBoard extends javax.swing.JFrame {

    //variables
    int roundNum = 0;
    int playerTurn = 0;
    GameLogic logic = new GameLogic();
    JToggleButton buttons[][];
    TerNodes terNodes[][] = new TerNodes[8][8];
    static int selected = 0;
    TerNodes temp1 = null;
    TerNodes temp2 = null;
    static final int LIMIT = 3;
    int turnsCompleted = 0;
    
    public RiskBoard() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        turnBox = new javax.swing.JScrollPane();
        turnText = new javax.swing.JTextArea();
        scoreBox = new javax.swing.JScrollPane();
        scoreText = new javax.swing.JTextArea();
        jSeparator1 = new javax.swing.JSeparator();
        turnButton = new javax.swing.JButton();
        placeArmyToggle = new javax.swing.JToggleButton();
        fortifyToggle = new javax.swing.JToggleButton();
        addPlayerButton = new javax.swing.JButton();
        addAIButton = new javax.swing.JButton();
        t1 = new javax.swing.JToggleButton();
        t2 = new javax.swing.JToggleButton();
        t3 = new javax.swing.JToggleButton();
        t4 = new javax.swing.JToggleButton();
        t5 = new javax.swing.JToggleButton();
        t6 = new javax.swing.JToggleButton();
        t7 = new javax.swing.JToggleButton();
        t8 = new javax.swing.JToggleButton();
        t9 = new javax.swing.JToggleButton();
        t10 = new javax.swing.JToggleButton();
        t11 = new javax.swing.JToggleButton();
        t12 = new javax.swing.JToggleButton();
        t13 = new javax.swing.JToggleButton();
        t14 = new javax.swing.JToggleButton();
        t15 = new javax.swing.JToggleButton();
        t16 = new javax.swing.JToggleButton();
        t17 = new javax.swing.JToggleButton();
        t19 = new javax.swing.JToggleButton();
        t18 = new javax.swing.JToggleButton();
        t20 = new javax.swing.JToggleButton();
        t21 = new javax.swing.JToggleButton();
        t22 = new javax.swing.JToggleButton();
        t23 = new javax.swing.JToggleButton();
        t24 = new javax.swing.JToggleButton();
        t25 = new javax.swing.JToggleButton();
        t26 = new javax.swing.JToggleButton();
        t27 = new javax.swing.JToggleButton();
        t28 = new javax.swing.JToggleButton();
        t29 = new javax.swing.JToggleButton();
        t30 = new javax.swing.JToggleButton();
        t32 = new javax.swing.JToggleButton();
        t31 = new javax.swing.JToggleButton();
        t33 = new javax.swing.JToggleButton();
        t34 = new javax.swing.JToggleButton();
        t35 = new javax.swing.JToggleButton();
        t36 = new javax.swing.JToggleButton();
        t37 = new javax.swing.JToggleButton();
        t38 = new javax.swing.JToggleButton();
        startButton = new javax.swing.JButton();
        t39 = new javax.swing.JToggleButton();
        t40 = new javax.swing.JToggleButton();
        t41 = new javax.swing.JToggleButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Risky");

        turnBox.setFocusable(false);

        turnText.setColumns(20);
        turnText.setRows(5);
        turnText.setFocusable(false);
        turnBox.setViewportView(turnText);

        scoreText.setColumns(20);
        scoreText.setRows(5);
        scoreText.setFocusable(false);
        scoreBox.setViewportView(scoreText);

        jSeparator1.setAutoscrolls(true);

        turnButton.setText("End Turn");
        turnButton.setEnabled(false);
        turnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                turnButtonActionPerformed(evt);
            }
        });

        placeArmyToggle.setText("Place Army");
        placeArmyToggle.setEnabled(false);
        placeArmyToggle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                placeArmyToggleActionPerformed(evt);
            }
        });

        fortifyToggle.setText("Fortify");
        fortifyToggle.setEnabled(false);
        fortifyToggle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fortifyToggleActionPerformed(evt);
            }
        });

        addPlayerButton.setText("Add Player");
        addPlayerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPlayerButtonActionPerformed(evt);
            }
        });

        addAIButton.setText("Add AI");
        addAIButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAIButtonActionPerformed(evt);
            }
        });

        t1.setText("Territory 1 (0)");
        t1.setEnabled(false);
        t1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t1ActionPerformed(evt);
            }
        });

        t2.setText("Territory 2 (0)");
        t2.setEnabled(false);
        t2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t2ActionPerformed(evt);
            }
        });

        t3.setText("Territory 3 (0)");
        t3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        t3.setEnabled(false);
        t3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t3ActionPerformed(evt);
            }
        });

        t4.setText("Territory 4 (0)");
        t4.setEnabled(false);
        t4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t4ActionPerformed(evt);
            }
        });

        t5.setText("Territory 5 (0)");
        t5.setEnabled(false);
        t5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t5ActionPerformed(evt);
            }
        });

        t6.setText("Territory 6 ()");
        t6.setEnabled(false);
        t6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t6ActionPerformed(evt);
            }
        });

        t7.setText("Territory 7 ()");
        t7.setEnabled(false);
        t7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t7ActionPerformed(evt);
            }
        });

        t8.setText("Territory 8 ()");
        t8.setEnabled(false);
        t8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t8ActionPerformed(evt);
            }
        });

        t9.setText("Territory 9 ()");
        t9.setEnabled(false);
        t9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t9ActionPerformed(evt);
            }
        });

        t10.setText("Territory 10 ()");
        t10.setEnabled(false);
        t10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t10ActionPerformed(evt);
            }
        });

        t11.setText("Territory 11 ()");
        t11.setEnabled(false);
        t11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t11ActionPerformed(evt);
            }
        });

        t12.setText("Territory 12 ()");
        t12.setEnabled(false);
        t12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t12ActionPerformed(evt);
            }
        });

        t13.setText("Territory 13 ()");
        t13.setEnabled(false);
        t13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t13ActionPerformed(evt);
            }
        });

        t14.setText("Territory 14 ()");
        t14.setEnabled(false);
        t14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t14ActionPerformed(evt);
            }
        });

        t15.setText("Territory 15 ()");
        t15.setEnabled(false);
        t15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t15ActionPerformed(evt);
            }
        });

        t16.setText("Territory 16 ()");
        t16.setEnabled(false);
        t16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t16ActionPerformed(evt);
            }
        });

        t17.setText("Territory 17 ()");
        t17.setEnabled(false);
        t17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t17ActionPerformed(evt);
            }
        });

        t19.setText("Territory 19 ()");
        t19.setEnabled(false);
        t19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t19ActionPerformed(evt);
            }
        });

        t18.setText("Territory 18 ()");
        t18.setEnabled(false);
        t18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t18ActionPerformed(evt);
            }
        });

        t20.setText("Territory 20 ()");
        t20.setEnabled(false);
        t20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t20ActionPerformed(evt);
            }
        });

        t21.setText("Territory 21 ()");
        t21.setEnabled(false);
        t21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t21ActionPerformed(evt);
            }
        });

        t22.setText("Territory 22 ()");
        t22.setEnabled(false);
        t22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t22ActionPerformed(evt);
            }
        });

        t23.setText("Territory 23 ()");
        t23.setEnabled(false);
        t23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t23ActionPerformed(evt);
            }
        });

        t24.setText("Territory 24 ()");
        t24.setEnabled(false);
        t24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t24ActionPerformed(evt);
            }
        });

        t25.setText("Territory 25 ()");
        t25.setEnabled(false);
        t25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t25ActionPerformed(evt);
            }
        });

        t26.setText("Territory 26 ()");
        t26.setEnabled(false);
        t26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t26ActionPerformed(evt);
            }
        });

        t27.setText("Territory 27 ()");
        t27.setEnabled(false);
        t27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t27ActionPerformed(evt);
            }
        });

        t28.setText("Territory 28 ()");
        t28.setEnabled(false);
        t28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t28ActionPerformed(evt);
            }
        });

        t29.setText("Territory 29 ()");
        t29.setEnabled(false);
        t29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t29ActionPerformed(evt);
            }
        });

        t30.setText("Territory 30 ()");
        t30.setEnabled(false);
        t30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t30ActionPerformed(evt);
            }
        });

        t32.setText("Territory 32 ()");
        t32.setEnabled(false);
        t32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t32ActionPerformed(evt);
            }
        });

        t31.setText("Territory 31 ()");
        t31.setEnabled(false);
        t31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t31ActionPerformed(evt);
            }
        });

        t33.setText("Territory 33 ()");
        t33.setEnabled(false);
        t33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t33ActionPerformed(evt);
            }
        });

        t34.setText("Territory 34 ()");
        t34.setEnabled(false);
        t34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t34ActionPerformed(evt);
            }
        });

        t35.setText("Territory 35 ()");
        t35.setEnabled(false);
        t35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t35ActionPerformed(evt);
            }
        });

        t36.setText("Territory 36 ()");
        t36.setEnabled(false);
        t36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t36ActionPerformed(evt);
            }
        });

        t37.setText("Territory 37 ()");
        t37.setEnabled(false);
        t37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t37ActionPerformed(evt);
            }
        });

        t38.setText("Territory 38 ()");
        t38.setEnabled(false);
        t38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t38ActionPerformed(evt);
            }
        });

        startButton.setText("Start Game");
        startButton.setEnabled(false);
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        t39.setText("Territory 39 ()");
        t39.setEnabled(false);
        t39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t39ActionPerformed(evt);
            }
        });

        t40.setText("Territory 40 ()");
        t40.setEnabled(false);
        t40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t40ActionPerformed(evt);
            }
        });

        t41.setText("Territory 41 ()");
        t41.setEnabled(false);
        t41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t41ActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountain.png"))); // NOI18N

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton2.setText("jButton2");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton3.setText("jButton3");

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.jpg"))); // NOI18N
        jButton4.setText("jButton4");

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountain.png"))); // NOI18N

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountain.png"))); // NOI18N

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton7.setText("jButton7");

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton8.setText("jButton8");

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mountain.png"))); // NOI18N

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton11.setText("jButton11");

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N
        jButton12.setText("jButton12");

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N

        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N

        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/water.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(t3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t31, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t26, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t32, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(t16, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(t17, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(t18, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(t24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(t29, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t27, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(t28, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(t6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, Short.MAX_VALUE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(t11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(t7, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addGap(18, 18, 18)
                                                        .addComponent(t8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addGap(18, 18, 18)
                                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(0, 0, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(t38, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(t12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(t9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, Short.MAX_VALUE))))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t30, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(t41, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(t40, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(t10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(t20, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(t39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 150, Short.MAX_VALUE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jButton13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, Short.MAX_VALUE)
                                            .addComponent(t19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                            .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(t33, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t34, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t35, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t36, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(t37, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(turnBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(addPlayerButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(addAIButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(startButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(turnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(placeArmyToggle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(fortifyToggle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(scoreBox, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator1))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t20, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t38, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t39, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t6, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t8, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t9, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t10, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(t5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(t11, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(t12, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(t40, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 4, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t16, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t17, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t18, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t19, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t24, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(t26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(t28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(t29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(t30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(t41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 75, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(t32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(t33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(t34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(t35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(t36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(t37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 75, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(t31, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(t27, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(116, 116, 116)))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scoreBox, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(turnBox, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(placeArmyToggle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(fortifyToggle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(turnButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(addPlayerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(addAIButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 3, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void turnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_turnButtonActionPerformed
        enableButtons();
        
        //resets turnsCompleted to 0
        turnsCompleted = 0;
        
        //deselects any selected buttons from previous turn
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                if (buttons[i][j] != null) {
                    buttons[i][j].setSelected(false);
                }
            }
        }
        
        //increases roundNum if the player at 0 is the first player.
        logic.endTurn();        
        if (logic.getQueue().get(0).getTeamColor().equals(Color.ORANGE)) {
            roundNum++;
        }
        
        if (roundNum != 0) {
            logic.getQueue().get(0).setAvalibleArmies(0);
            logic.armyCalc(logic.getQueue().get(0));
            logic.draw();
            
        }
        
        for (int i = 0; i < logic.getQueue().size(); i++) {
            logic.getQueue().get(i).setTerritoryControlled(0);
            logic.getQueue().get(i).setTotalArmies(0);
        }
        
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                if (buttons[i][j] != null) {
                    terNodes[i][j].getOwner().setTerritoryControlled(terNodes[i][j].getOwner().getTerritoryControlled()+1);
                    terNodes[i][j].getOwner().setTotalArmies(terNodes[i][j].getArmies()+terNodes[i][j].getOwner().getTotalArmies());
                }
            }
        }
        
        setTexts();
       
        placeArmyToggle.setSelected(false);
        fortifyToggle.setSelected(false);
    }//GEN-LAST:event_turnButtonActionPerformed

    private void placeArmyToggleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_placeArmyToggleActionPerformed
         fortifyToggle.setSelected(false);
         setTemp1();
        
        //places armies to temp1
        if (temp1 != null && logic.getQueue().get(0).getNumFort() >= 1) {
            logic.placeArmy(temp1, logic.getQueue().get(0));
            buttons[temp1.getI()][temp1.getJ()].setSelected(false);
            
            setTexts();
        }
        
        placeArmyToggle.setSelected(false);
        temp1 = null;
        selected =0;
    }//GEN-LAST:event_placeArmyToggleActionPerformed

    private void fortifyToggleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fortifyToggleActionPerformed
        placeArmyToggle.setSelected(false);
        
        setTemp1();
        
        //fortifies temp1 if it is clicked first and then fortify is clicked
        if (temp1 != null && logic.getQueue().get(0).getNumFort() >= 1) {
            logic.fortify(temp1);
            buttons[temp1.getI()][temp1.getJ()].setSelected(false);
            
            setTexts();
        }
        
        fortifyToggle.setSelected(false);
        temp1 = null;
        selected =0;
    }//GEN-LAST:event_fortifyToggleActionPerformed

    private void addAIButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAIButtonActionPerformed
        //not implemented
    }//GEN-LAST:event_addAIButtonActionPerformed

    private void addPlayerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPlayerButtonActionPerformed
        logic.addPlayer();
        turnText.append("\n" + logic.getQueue().get(playerTurn).getTeamName() + " added, " + (playerTurn + 1) + " players in the game.");
        playerTurn++;
        
        if (playerTurn == 2) {
            startButton.setEnabled(true);
        }
        if (playerTurn == 4) {
            addPlayerButton.setEnabled(false);
            addAIButton.setEnabled(false);
        }
    }//GEN-LAST:event_addPlayerButtonActionPerformed

    private void t2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t2ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t2ActionPerformed

    private void t1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t1ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t1ActionPerformed

    private void t3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t3ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t3ActionPerformed

    private void t4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t4ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t4ActionPerformed

    private void t5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t5ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t5ActionPerformed

    private void t6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t6ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t6ActionPerformed

    private void t7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t7ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t7ActionPerformed

    private void t8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t8ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t8ActionPerformed

    private void t9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t9ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t9ActionPerformed

    private void t10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t10ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t10ActionPerformed

    private void t11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t11ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t11ActionPerformed

    private void t12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t12ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t12ActionPerformed

    private void t13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t13ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t13ActionPerformed

    private void t14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t14ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t14ActionPerformed

    private void t15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t15ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t15ActionPerformed

    private void t16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t16ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t16ActionPerformed

    private void t17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t17ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t17ActionPerformed

    private void t18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t18ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t18ActionPerformed

    private void t19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t19ActionPerformed
       selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t19ActionPerformed

    private void t20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t20ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t20ActionPerformed

    private void t21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t21ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t21ActionPerformed

    private void t22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t22ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t22ActionPerformed

    private void t23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t23ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t23ActionPerformed

    private void t24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t24ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t24ActionPerformed

    private void t25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t25ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t25ActionPerformed

    private void t26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t26ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t26ActionPerformed

    private void t27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t27ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t27ActionPerformed

    private void t28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t28ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t28ActionPerformed

    private void t29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t29ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t29ActionPerformed

    private void t30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t30ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t30ActionPerformed

    private void t31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t31ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t31ActionPerformed

    private void t32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t32ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t32ActionPerformed

    private void t33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t33ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t33ActionPerformed

    private void t34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t34ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t34ActionPerformed

    private void t35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t35ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t35ActionPerformed

    private void t36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t36ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t36ActionPerformed

    private void t37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t37ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t37ActionPerformed

    private void t38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t38ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t38ActionPerformed

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        //enables buttons to "start" the game
        addAIButton.setEnabled(false);
        addPlayerButton.setEnabled(false);
        placeArmyToggle.setEnabled(true);
        fortifyToggle.setEnabled(true);  
        startButton.setEnabled(false);
        turnButton.setEnabled(true);
       
        //calls makeArray method to assign to buttons
        buttons = makeArray();
        
        //sets up nodes of TerNodes
        ArrayList nodes = new ArrayList<TerNodes>();
        
        //populates the cards
        logic.populate();
        
        //sets up random number generator
        Random rand = new Random();
        
        //reads the territory names from a file and names the territories.
        //assigns the territory to a random player with a random number of troops from 6 to 24.
        try{
            Scanner inFile = new Scanner( new FileReader( "./src/names.txt" ) );  
        
            for (int i = 0; i < buttons.length; i++) {
                for (int j = 0; j < buttons[i].length; j++) {
                    if (buttons[i][j] != null) {
                        buttons[i][j].setEnabled(true);
                        String name = inFile.nextLine();
                        TerNodes n1 = new TerNodes(name, null, (rand.nextInt(16) + 6), 0, buttons[i][j], i, j);
                        nodes.add(n1);
                        terNodes[i][j] = n1;
                    }
                }
            }
         
        }//end try
        catch (IOException e){
            JOptionPane.showMessageDialog(null, "File not found");
        }
        
        int p = 0;
        
        //Sets the terNodes to the respective owner
        while (nodes.size() != 0) {
            TerNodes temp = (TerNodes) (nodes.get(rand.nextInt(nodes.size())));
            if (p == 0) {
                temp.setOwner(logic.getQueue().get(p));
                p++;
            }
            else if (p == 1) {
                temp.setOwner(logic.getQueue().get(p));
                p++;
            }
            else if (p == 2) {
                temp.setOwner(logic.getQueue().get(p));
                p++;
            }
            else {
                temp.setOwner(logic.getQueue().get(p));
                p = 0;
            }
            if(p>=logic.getQueue().size()) {
                p = 0;
            }
            
            nodes.remove(temp);
        }
        
        for (int i = 0; i < logic.getQueue().size(); i++) {
            logic.getQueue().get(i).setTerritoryControlled(0);
            logic.getQueue().get(i).setTotalArmies(0);
            logic.getQueue().get(i).setNumFort(1);
        }
        
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                if (buttons[i][j] != null) {
                    terNodes[i][j].getOwner().setTerritoryControlled(terNodes[i][j].getOwner().getTerritoryControlled()+1);
                    terNodes[i][j].getOwner().setTotalArmies(terNodes[i][j].getArmies()+terNodes[i][j].getOwner().getTotalArmies());
                    
                }
            }
        }
        
        setTexts();
    }//GEN-LAST:event_startButtonActionPerformed

    private void t39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t39ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t39ActionPerformed

    private void t40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t40ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t40ActionPerformed

    private void t41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t41ActionPerformed
        selected++;
        
        setTemp1();
        setTemp2();
        makeMove();
        setTexts();
    }//GEN-LAST:event_t41ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RiskBoard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RiskBoard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RiskBoard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RiskBoard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RiskBoard().setVisible(true);
            }          
        });
    }

    public JToggleButton[][] makeArray() {
        //places the buttons into the 2d array based on their position on the board
        JToggleButton button[][] = { {t1, t2, null, null, t38, null, t20, t39}, 
                                     {t3, t4, t6, t7, t8, t9, t10, null},
                                     {null, t5, null, t11, null, t12, t13, t40},
                                     {null, t14, t15, t16, t17, t18, t19, null},
                                     {t21, t22, null, t23, t24, t25, null, null},
                                     {null, t26, t27, t28, null, t29, t30, t41},
                                     {t31, t32, t33, t34, t35, t36, t37, null} };
        
        return button;
    }
    
    public void disableButtons() {
        //goes through and disables all the buttons on the board
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                if (buttons[i][j] != null) {
                    buttons[i][j].setSelected(false);
                    buttons[i][j].setEnabled(false);
                }
            }
        }
        
        placeArmyToggle.setEnabled(false);
        fortifyToggle.setEnabled(false);
    }
    
    public void enableButtons() {
        //goes through and enables all the buttons on the game board
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                if (buttons[i][j] != null) {
                    buttons[i][j].setSelected(false);
                    buttons[i][j].setEnabled(true);
                }
            }
        }
        placeArmyToggle.setEnabled(true);
        fortifyToggle.setEnabled(true);
    }
    
    public void setTexts() {
        //sets the texts to the current player's turn
        scoreText.setForeground(logic.getQueue().get(0).getTeamColor());
        scoreText.setText("---------------------------------------" +
                          "\n" + logic.getQueue().get(0).toString() + 
                          "\n-------------------------------------");
        
        turnText.setForeground(logic.getQueue().get(0).getTeamColor());
        turnText.setText("---------------------------------------" + 
                         "\nRound: " + roundNum +
                         "\nPlayer: " + logic.getQueue().get(0).getTeamName() +
                         "\nMoves: " + (turnsCompleted + 1) + " / " + LIMIT +
                         "\n---------------------------------------");
        }
    
    public void setTemp1() {
        //assigns temp1 to the button that is currently selected
        if (selected == 1) {
            for (int i = 0; i < buttons.length; i++) {
                for (int j = 0; j < buttons[i].length; j++) {
                    if (buttons[i][j] != null && buttons[i][j].isSelected()) {
                        temp1 = terNodes[i][j];
                        buttons[i][j].setSelected(false);
                    }
                }
            }
        }
    }
    
    public void setTemp2() {
        //assigns temp2 to the button that is currently
        if (selected == 2){
            for (int i = 0; i < buttons.length; i++) {
                for (int j = 0; j < buttons[i].length; j++) {
                    if (buttons[i][j] != null && buttons[i][j].isSelected()) {
                        temp2 = terNodes[i][j];
                        buttons[i][j].setSelected(false);
                    }
                    
                }
            }
        }
    }
    
    public void makeMove() {
        //if both current terNodes selected are owned by the same player, call move method from GameLogic
        if (temp1 != null && temp2 != null && temp1.getOwner().equals(temp2.getOwner())) {
            if (logic.move(temp1, temp2)) {
                selected = 0;
                temp1 = null;
                temp2 = null;
                turnsCompleted++;
            }
            else {
                selected = 0;
                temp1 = null;
                temp2 = null;                 
            }
        }
        
        //if terNodes are owned by opposing players, call attack method from GameLogic
        else if (temp1 != null && temp2 != null) {
            if (logic.attack(temp1, temp2)) {
                selected = 0;
                temp1 = null;
                temp2 = null;
                turnsCompleted++;
            }
            else {
                selected = 0;
                temp1 = null;
                temp2 = null;                 
            }
        }
 
        //if turnsCompleted == LIMIT, forces the player to end their turn.
        if (turnsCompleted == LIMIT) {
            disableButtons();
            turnsCompleted = 0;
            JOptionPane.showMessageDialog(null, "Out of turns, must END TURN.");
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addAIButton;
    private javax.swing.JButton addPlayerButton;
    private javax.swing.JToggleButton fortifyToggle;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JToggleButton placeArmyToggle;
    private javax.swing.JScrollPane scoreBox;
    private javax.swing.JTextArea scoreText;
    private javax.swing.JButton startButton;
    private javax.swing.JToggleButton t1;
    private javax.swing.JToggleButton t10;
    private javax.swing.JToggleButton t11;
    private javax.swing.JToggleButton t12;
    private javax.swing.JToggleButton t13;
    private javax.swing.JToggleButton t14;
    private javax.swing.JToggleButton t15;
    private javax.swing.JToggleButton t16;
    private javax.swing.JToggleButton t17;
    private javax.swing.JToggleButton t18;
    private javax.swing.JToggleButton t19;
    private javax.swing.JToggleButton t2;
    private javax.swing.JToggleButton t20;
    private javax.swing.JToggleButton t21;
    private javax.swing.JToggleButton t22;
    private javax.swing.JToggleButton t23;
    private javax.swing.JToggleButton t24;
    private javax.swing.JToggleButton t25;
    private javax.swing.JToggleButton t26;
    private javax.swing.JToggleButton t27;
    private javax.swing.JToggleButton t28;
    private javax.swing.JToggleButton t29;
    private javax.swing.JToggleButton t3;
    private javax.swing.JToggleButton t30;
    private javax.swing.JToggleButton t31;
    private javax.swing.JToggleButton t32;
    private javax.swing.JToggleButton t33;
    private javax.swing.JToggleButton t34;
    private javax.swing.JToggleButton t35;
    private javax.swing.JToggleButton t36;
    private javax.swing.JToggleButton t37;
    private javax.swing.JToggleButton t38;
    private javax.swing.JToggleButton t39;
    private javax.swing.JToggleButton t4;
    private javax.swing.JToggleButton t40;
    private javax.swing.JToggleButton t41;
    private javax.swing.JToggleButton t5;
    private javax.swing.JToggleButton t6;
    private javax.swing.JToggleButton t7;
    private javax.swing.JToggleButton t8;
    private javax.swing.JToggleButton t9;
    private javax.swing.JScrollPane turnBox;
    private javax.swing.JButton turnButton;
    private javax.swing.JTextArea turnText;
    // End of variables declaration//GEN-END:variables
}