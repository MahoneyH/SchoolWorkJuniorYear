/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oy5836jw
 */
import java.awt.Color;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class GameLogic implements LogicInterface {
    //constant used in Army calc method
    final int ARMY_MULT =5; //this belongs to ArmyCalc method, number that Multiplier told troop placement
    final int ARMY_DIV =2;  //This belongs to ArmyCalc method, number that divides troop placement
    //end constant used in army calc method
    
    //constants used in dice rolling method
    final int ROLL_CALC =10;//this belongs to roll method calc the number of rolls you get per number of troops
    final int NICE_WIN = 1; //difference of dice of 3 or less
    final int GOOD_WIN =2;  //difference of dice 4 to 6
    final int GREAT_WIN =3; //difference of dice 7 or 8
    final int PERFECT_WIN =5; //difference of dice 9
    final int TIE_BATTLE =1;  //dice are the same
    //end constants of dice rolling method
   
    //queue player order
     static ArrayList<Player> queue = new ArrayList<Player>();
    //stack for cards
     static ArrayList<Cards> deck = new ArrayList<Cards>();
     
     //-----------------------Start Methods------------------------------------------------//
    //End turn
     public void endTurn(){
         queue.add(queue.get(0));
         queue.remove(0);
         queue.get(0).setNumFort(1);
     }
      //-----------------------------------------------------------------------//
     
     
    //Get queue
     public ArrayList<Player> getQueue(){
         return queue;
     }
     //-----------------------------------------------------------------------//
     
     
//add player
     public String addPlayer(){
         //colors ORANGE CYAN PINK GREEN
         String name ="";
         int Controlled;
         int totalArmies;
         int avalibleArmies;
         int numFort;
         int playerCount = queue.size();
         Player player ;
         
         name = JOptionPane.showInputDialog("Enter Player Name: ");
         //Assign color, based on the number of players in the game.
         if(playerCount ==0){
            player = new Player(name, Color.ORANGE,0,0,0,0);
            queue.add(player);
         }
         else if(playerCount ==1){
            player = new Player(name, Color.CYAN,0,0,0,0);
            queue.add(player);
         }
         else if(playerCount ==2){
            player = new Player(name, Color.PINK,0,0,0,0);
            queue.add(player);
         }
          else {
            player = new Player(name, Color.GREEN,0,0,0,0);
            queue.add(player);
         }
            
         return player.getTeamName();
     
     }
      //-----------------------------------------------------------------------//
     
     
    //add AI note add this if we have time.
     public String addAI(){
         return null;
     }
      //-----------------------------------------------------------------------//
     
     
    //place army
     public void placeArmy(TerNodes node, Player player){
         int numToPlace =0;
         
         int remainToPlace = player.getAvalibleArmies();
         if(node.getOwner().equals(player)){
         
         try{
            numToPlace = Integer.parseInt(JOptionPane.showInputDialog("Enter number to place: "));
            //handle and input less than 0, or greater than number of armies avalible.
            if(numToPlace > remainToPlace || numToPlace < 0){
                numToPlace = 0;
                JOptionPane.showMessageDialog(null, "Invalid input, please input a Number less than or " + "\n" +
                                            "equal to " + remainToPlace);
                placeArmy(node, player);
                
            }
            
          
         }
         //catch input of a string or none, interger issue.
         catch(InputMismatchException e){
                JOptionPane.showMessageDialog(null, "Invalid input, please input a Number less than or " + "\n" +
                                            "equal to " + remainToPlace);
                placeArmy(node, player);
         }
         catch(NumberFormatException e){
             
                JOptionPane.showMessageDialog(null, "Invalid input, please input a Number less than or " + "\n" +
                                            "equal to " + remainToPlace);
                placeArmy(node, player);
                 
                }
         
         
         //update node, and update avalible armies to place                
         node.setArmies(node.getArmies()+numToPlace);
         player.setAvalibleArmies(player.getAvalibleArmies()-numToPlace);
         }
                  
         
     }
     
     //-----------------------------------------------------------------------//
     
     
    //fortify
    public void fortify(TerNodes node){
        if(node.getOwner().equals(queue.get(0))){
            node.setFortified(node.getFortified()+1);
            queue.get(0).setNumFort(queue.get(0).getNumFort()-1);
        }
    }
     //-----------------------------------------------------------------------//
    
    
    
     //-----------------------------------------------------------------------//
    
    
    //dice rolling
    public void diceRoll(TerNodes one, TerNodes two){
        int attack,loss;
        int defend;
        int oneHigh=0;
        int twoHigh=0;
        int roll;
        boolean flag =true;
        int AttackingArmy = one.getArmies();
        int Defenders = two.getArmies();
        //create an object to roll and random number, using Java built in util.
        Random rand = new Random();
        //Start Do while loop
        do{
        attack = one.getArmies();
        defend = two.getArmies();
        //determine number of rolls they get, based on troops count of 10 or less
        if(attack == ROLL_CALC){
            attack =1;
        }
        //determine number of troops based, on having 10+ troops
        else if(attack > ROLL_CALC){
            attack = attack / ROLL_CALC;
            //added
            if(attack > 5){
                attack =5;
            }
            //---
        }
        //added
        else if(attack ==0){
            attack =0;
            break;
        }
        //------
        oneHigh = 0;
        //Roll randon number = numbter of attack, save highest roll
        while(attack !=0){
            roll = rand.nextInt(10);
            if(roll > oneHigh){
                oneHigh = roll;
            }
            attack--;
            
        }
        //same pattern as the Attacker rolls
        if(defend ==ROLL_CALC ){
            defend = 1;
        }
        else if(defend>ROLL_CALC){
            defend = defend/ROLL_CALC;
            //added
            if(defend > 4){
                defend =4;
            }
            //----
        }
        else if(defend ==0){
            defend =0;
        }
        if(two.getFortified()>0&& defend !=0){
            defend = defend + two.getFortified();
        }
        
        twoHigh =0;
         while(defend !=0){
            roll = rand.nextInt(10); 
            if(roll > twoHigh){
                twoHigh = roll;
            }
            defend--;
            
        }//end while
        //Check for winner
        /*
             ATTACKING                                      DEFENDING
        Lose 1 army                     TIE                         Lose 1 army
        Lose 1.                      Difference of 1,2,3.           Lose 1 army
        Lose 2.                      Difference of 4,5,6.           Lose 2 army
        Lose 3.                      Difference of 7,8.             Lose 3
        Lose 5.                      Difference of 9.               Lose 5

         */
        if(oneHigh > twoHigh){
            //difference of 1,2,3
            if(oneHigh -1 == twoHigh ||oneHigh -2 == twoHigh || oneHigh -3 == twoHigh){ //check the difference of the dice roll
                two.setArmies(two.getArmies()-NICE_WIN);
                if(two.getArmies() <= 0){
                    two.setArmies(0);
                    
                     flag = false;
                    
                }
               
            }   //fifference of 4,5,6
            else if(oneHigh -4 == twoHigh ||oneHigh -5 == twoHigh || oneHigh -6 == twoHigh){
                two.setArmies(two.getArmies()-GOOD_WIN);
                if(two.getArmies() <= 0){
                    two.setArmies(0);
                    
                    
                     flag = false;
                }
                
                //difference of 7 or 8
            }else if(oneHigh -7 == twoHigh ||oneHigh -8 == twoHigh){
                two.setArmies(two.getArmies()-GREAT_WIN);
                if(two.getArmies() <= 0){
                    two.setArmies(0);
                    
                    
                     flag = false;
                }
                
            }//9 difference
            else if(oneHigh -9 == twoHigh){
                two.setArmies(two.getArmies()-PERFECT_WIN);
                if(two.getArmies() <= 0){
                    two.setArmies(0);
                    
                     flag = false;
                }
            
            }
            
        }
        else if(oneHigh < twoHigh){
            //difference of 1,2,3
            if(oneHigh +1 == twoHigh ||oneHigh +2 == twoHigh || oneHigh +3 == twoHigh){
                one.setArmies(one.getArmies()-NICE_WIN);
                if(one.getArmies() <= 0){
                    one.setArmies(0);
                    flag = false;
                }
                
            }   //fifference of 4,5,6
            else if(oneHigh +4 == twoHigh ||oneHigh +5 == twoHigh || oneHigh +6 == twoHigh){
                one.setArmies(one.getArmies()-GOOD_WIN);
                if(one.getArmies() <= 0){
                    one.setArmies(0);
                    
                    
                     flag = false;
                }
    
                //difference of 7 or 8
            }else if(oneHigh +7 == twoHigh ||oneHigh +8 == twoHigh){
                one.setArmies(one.getArmies()-GREAT_WIN);
                if(one.getArmies() <= 0){
                    one.setArmies(0);
                    
                    
                    flag = false;
                }
                
            }//9 difference
            else if(oneHigh +9 == twoHigh){
                one.setArmies(one.getArmies()-PERFECT_WIN);
                if(one.getArmies() <= 0){
                    one.setArmies(0);
                    
                    
                    flag = false;
                }
                
            }
                
        }
        else{//tie 
                two.setArmies(two.getArmies()-TIE_BATTLE);
                one.setArmies(one.getArmies()-TIE_BATTLE);
                if(one.getArmies() <= 0){
                    one.setArmies(0);
                    
                }
                if(two.getArmies() <= 0){
                    two.setArmies(0);
                    
                }
                
            }
      
        }while(flag);
        //attackers lost
        if(one.getArmies()==0 && two.getArmies()!=0){
            loss = Defenders -two.getArmies();
            JOptionPane.showMessageDialog(null, "Defeat! Defenders Win!" + "\n" +
                                           "Attacks Lost All Armies!" + "\n" +
                                           "Defenders suffers " + loss + " losses");
            
            one.getOwner().setTotalArmies(one.getOwner().getTotalArmies()-AttackingArmy);
            two.getOwner().setTotalArmies(two.getOwner().getTotalArmies()-loss);
            
            //if player lost last territory remove them from queue
            if(one.getOwner().getTerritoryControlled()==0){
                for(int i =0; i<queue.size();i++){
                    if(one.getOwner().getTeamColor().equals(queue.get(i).getTeamColor()))
                            queue.remove(i);
                    }
               
            }
            
        }
        //defenders lost
        else if(two.getArmies()==0 && one.getArmies()!=0){
            loss = AttackingArmy - one.getArmies();
            JOptionPane.showMessageDialog(null, "Victory! Attackers Win!" + "\n" +
                                                "Defenders Lost All Armies!" + "\n" +
                                                "Attackers suffers " + loss + " losses");
            //if player lost last territory remove them from the queue
            
            
            one.getOwner().setTerritoryControlled(one.getOwner().getTerritoryControlled()+1);
            one.getOwner().setTotalArmies(one.getOwner().getTotalArmies()-loss);
            two.getOwner().setTerritoryControlled(two.getOwner().getTerritoryControlled()-1);
            two.getOwner().setTotalArmies(two.getOwner().getTotalArmies()-Defenders);
            two.setFortified(0);
            //move number of armies into the new territory
            move(one,two);
            
            
            if(two.getOwner().getTerritoryControlled()==0){
                for(int i =0; i<queue.size();i++){
                    if(two.getOwner().getTeamColor().equals(queue.get(i).getTeamColor()))
                            queue.remove(i);
                            checkWin();
                    }
                //queue.remove(two.getOwner());
            }
            two.setOwner(one.getOwner());
        }
        else{
            JOptionPane.showMessageDialog(null, "Stalemate!" + "\n" +
                                                "Defenders Lost All Armies!" + "\n" +
                                                "Attackers Lost All Armies ");
            one.getOwner().setTotalArmies(one.getOwner().getTotalArmies()-AttackingArmy);
            two.getOwner().setTotalArmies(two.getOwner().getTotalArmies()-Defenders);
            
            
        }
        
        
    }
     //-----------------------------------------------------------------------//
    
    
    
     //-----------------------------------------------------------------------//
    
    //check winner
    public void checkWin(){
        if(queue.size()==1){
            JOptionPane.showMessageDialog(null, "Winner! Winner! Chicken Dinner!" + "\n" +
                                                "Congrats To: " + queue.get(0).getTeamName());
        }
    }
    
     //-----------------------------------------------------------------------//
    //Place army calculator
    /*
        5 times amount territories
    */
    public int armyCalc(Player player){
        int addedArmies;
        addedArmies = (player.getTerritoryControlled() *ARMY_MULT)/ARMY_DIV;
        player.setAvalibleArmies(player.getAvalibleArmies()+addedArmies);
        
        return addedArmies;
         
    }
    
     //-----------------------------------------------------------------------//
    //draw card
    @Override
    public Cards draw() {
        Random rand = new Random();
        int getCard = rand.nextInt(20);
        int effect =0;
        Cards card = deck.get(getCard);
        
        effect = card.getEffect();
        
        if(effect > 0){
            JOptionPane.showMessageDialog(null, card.getDesc() + "\nArmies to Added to Place: " + effect);
            
        }
        else{
            JOptionPane.showMessageDialog(null, card.getDesc() +"\nArmies Lost to Place: " + effect);
        }
        
        queue.get(0).setAvalibleArmies(queue.get(0).getAvalibleArmies()+effect);
        return card;       
    }
    
     //-----------------------------------------------------------------------//

   
    //Attack
    @Override
    public boolean attack(TerNodes one, TerNodes two) {
        boolean check = false;
        //this needs to use the algrothmn we created for the 2D array
        //attack is one, defender is two
       if(one.getOwner().equals(queue.get(0))){
           
            if(one.getI()==two.getI() && (one.getJ()+1 == two.getJ() || one.getJ()-1 == two.getJ()) ){
                diceRoll(one,two);
                check = true;
            }
            else if(one.getJ()==two.getJ() &&(one.getI()+1 == two.getI() || one.getI()-1 == two.getI())){
                diceRoll(one,two);
                check = true;
            }
            else{
                JOptionPane.showMessageDialog(null,"Cant Reach");
                check = false;
            }
       }
       else{
           JOptionPane.showMessageDialog(null,"Not your territory!");
           check = false;
       }
            return check;
        
    }

    //------------------------------------------------------------------------//
    //Move from first two second
    @Override
    public boolean move(TerNodes one, TerNodes two) {
        //this needs to use the algrothmn we created for the 2D array
        int moveTroops =0;
        boolean flag = false;
        try{
            if(one.getOwner().equals(queue.get(0))){
                if(one.getI()==two.getI() && (one.getJ()+1 == two.getJ() || one.getJ()-1 == two.getJ()) ){
                
                    moveTroops = Integer.parseInt(JOptionPane.showInputDialog("Available to move: " + one.getArmies() + 
                                                                    "\n" + "Enter number to place: "));
                    if(moveTroops > one.getArmies() || moveTroops < 0){
                        moveTroops = 0;
                    }
                    two.setArmies(two.getArmies()+moveTroops);
                    one.setArmies(one.getArmies()-moveTroops);
                    flag = true;
        
                }
                else if(one.getJ()==two.getJ() &&(one.getI()+1 == two.getI() || one.getI()-1 == two.getI())){
                moveTroops = Integer.parseInt(JOptionPane.showInputDialog("Available to move: " + one.getArmies() + 
                                                                    "\n" + "Enter number to place: "));
                    if(moveTroops > one.getArmies() || moveTroops < 0){
                        moveTroops = 0;
                    }
                    two.setArmies(two.getArmies()+moveTroops);
                    one.setArmies(one.getArmies()-moveTroops);
                    flag =true;
                }
                else{
                    JOptionPane.showMessageDialog(null,"Cant Reach");
                    flag =false;
            
                }
            }
            else{
                JOptionPane.showMessageDialog(null,"Not your territory");
                flag = false;
            }
        }
        catch(InputMismatchException e){
            JOptionPane.showMessageDialog(null, "Invalid input, please input a Number less than or " + "\n" +
                                            "equal to " + one.getArmies());
                move(one, two);
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Invalid input, please input a Number less than or " + "\n" +
                                            "equal to " + one.getArmies());
                move(one, two);
        }
        return flag;
         
    }
    
     public void populate() {
        
        
        try {
            try (Scanner inFile = new Scanner( new FileReader( "./src/cards.txt" ) )) {
                
                while(inFile.hasNext()) {
                    String description = inFile.nextLine();
                    int effectCard = Integer.parseInt(inFile.nextLine());
                    
                    
                   Cards temp;
                   temp = new Cards(description,effectCard);
                   
                   deck.add(temp);
                   
                   
                    
                    
                }
            }
        }
        catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File not found");
        }
        
    }
    
    
    
}
