
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oy5836jw
 */
public interface LogicInterface {
    
    //queue player order
    ArrayList<Player> queue = new ArrayList<Player>();
    //stack for cards
    ArrayList<Cards> stack = new ArrayList<Cards>();
    //graph for terr
    
    
    //End turn
    /**
     *This method will update the Queue, after the end turn button is pressed.
     *<br> <b>Require</b>This method requires that a game is running, and at least two players are left.
     *<br> <b>Ensure</b>This method will be sure to update the queue after the end turn button is pressed.
     */
    public void endTurn();
    //add player

    /**
     *This method will allow the user, to Add up to four players to the game, <br>
     * and place them within the queue.
     *<br> <b>Require</b>The game must be running, and you must enter a team name for each player.
     *<br> <b>Ensure</b>That the player object is created, and added into the queue, with a color.
     * @return
     */
        public String addPlayer();
    //add AI

    /**
     * This method will, allow the user to add an AI to the game, and allow them to play against the AI.
     *<br><b>Require</b>That the user presses the Add AI button.
     *<br> <b>Ensure</b>That the AI is constructed and added into the queue.
     * @return
     */
        public String addAI();
    //place army

    /**
     *This method will allow the current player to place armies give to them on their turn <br>
     * to a territory that they control.
     * <br><b>Require</b>That it is a players turn, that they own the selected territories, and <br>
     *              that they have armies available to be placed. 
     * <br><b>Ensure</b>That the territory selected is updated to reflect the extra number of troops added <br>
     *              and to update the number of troops available to be place is updated correctly.
     * @param node
     * @param player
     */
        public void placeArmy(TerNodes node, Player player);
    //fortify

    /**
     *This method will allow a Player to fortify a territory, By fortifying  <br>
     * the territory they will gain an extra dice roll, for each fortification on that territory <br>
     * but only when they are on the defending side.
     * <br><b>Require</b>That the play owners that node, and that they have fortifies available.
     * <br><b>Ensure</b>That the node.getFortified, is updated by one when fortified. 
     * @param node
     */
        public void fortify(TerNodes node);

  
    //dice rolling

    /**
     *This method will determine the winner of an attack and defense based of random numbers<br>
     * It will roll equal to the number of armies divide by 10 <br>
     * It will also repeat until a winner is declared.
     * <br><b>Require</b>That the current player is attacking with a node they control, and that<br>
     * the second node, is within reach and is controlled by an opposing player.
     * <br><b>Ensure</b>That the attack doesn't end until one sides nodes, is out of armies.<br>
     *              It will also update the losing node, to the winning players color. <br>
     *              It will also move 1 army from winning node, onto the loser sides node.
     * @param one
     * @param two
     */
        public void diceRoll(TerNodes one, TerNodes two);
    //attack method

    /**
     *This method will call the dice rolling method, and determine if the defending node <br>
     * can be attacked by attacking node.
     * <br><b>Require</b>Two nodes to be selected, and that the defending node is reachable by attacking node.
     *              And that the attacking node has more than 1 army on it.
     * <br><b>Ensure</b>That the two nodes, will attack and defend if able, and to call the dice rolling method.
     * @param one
     * @param two
     * @return boolean if attack went through
     */
        public boolean attack(TerNodes one, TerNodes two);
    
    //check winner

    /**
     *This method will determine if there is a winner, based on the number of people in the queue.
     * <br><b>Require</b>This method needs a queue to be looked through.
     * <br><b>Ensure</b>That if the queue only has one player, that player is declared the winner.
     */
        public void checkWin(); //check queue
    //Place army calculator

    /**
     *This method will calculate number of armies the current player gets based off of, <br>
     * The number of territories they control times 5.
     * <br><b>Require</b>The current player node control count. 
     * <br><b>Ensure</b>That the current players available armies to place is updated based on the calculated number.
     * @param player
     * @return int
     */
        public int armyCalc(Player player);
    //draw card

    /**
     *This method will draw a card, and apply the effect on the card to the current player.
     * <br><b>Require</b>That a stack of cards is filled, and that the game has started.
     * <br><b>Ensure</b>That the player is affected by the card either for better or worse<br>
     *              and that card is removed from the stack.
     * 
     * @return the card that was drawn.
     */
     public Cards draw();
    //move

    /**
     *This method will allow a player to move troops from one of their nodes to another of their nodes <br>
     * providing that the nodes are within moving distance of each other.
     * <br><b>Require</b>Two nodes are selected that are owned by the current player. and are able to interact.
     * <br><b>Ensure</b>That the number of troops you wish to move is removed from the first node<br>
     *              and that same number of troops is added to the next selected node.
     * @param one
     * @param two
     * 
     * @return boolean if move was success
     */
        public boolean move(TerNodes one, TerNodes two);
        
    /**
     * This method will load in the card data, for the game.
     * <br><b>Require</b> That the game is loaded, up and a file of cards is available.
     * <br><b>Ensure</b> that he card objects are created and are ready for use in the game.
     */
    public void populate();
    
    
}
